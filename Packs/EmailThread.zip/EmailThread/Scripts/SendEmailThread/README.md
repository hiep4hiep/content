Send email reply

## Script Data
---

| **Name** | **Description** |
| --- | --- |
| Script Type | python3 |
| Tags | emailthread |
| Cortex XSOAR Version | 6.5.0 |

## Inputs
---

| **Argument Name** | **Description** |
| --- | --- |
| files | Files |
| attachment | Attachment |
| email_to | Email To |
| email_cc | Email CC |
| email_bcc | Email BCC |
| email_subject | Email Subject |
| email_body | Email Body |
| email_from | Email From |
| email_body_html | Email body in HTML |
| integration_name | Integration instance name which XSOAR uses to send email |

## Outputs
---
There are no outputs for this script.

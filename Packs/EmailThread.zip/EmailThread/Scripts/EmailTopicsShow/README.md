[Enter a description of the script, including what function it performs and any important information users need to know, for example required permissions.]

## Script Data
---

| **Name** | **Description** |
| --- | --- |
| Script Type | python3 |
| Tags | field-change-triggered, emailthread |
| Cortex XSOAR Version | 6.5.0 |

## Inputs
---
There are no inputs for this script.

## Outputs
---

| **Path** | **Description** | **Type** |
| --- | --- | --- |
| BaseScript.Output | \[Enter a description of the data returned in this output.\] | String |

The script will run when selecting EmailTopic field on the layout to display the list of available topics

## Script Data
---

| **Name** | **Description** |
| --- | --- |
| Script Type | python3 |
| Tags | field-change-triggered, dbs |
| Cortex XSOAR Version | 6.5.0 |

## Inputs
---
There are no inputs for this script.

## Outputs
---
There are no outputs for this script.
